create
    definer = root@localhost procedure FuncionárioAcedeDonativo(IN id_Funcionário int, IN id_Donativo int, IN quantidadeUsada double)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: Algum Id está incorreto' AS Resultado;
    END;
     START TRANSACTION;
    IF EXISTS (SELECT 1 FROM Funcionário WHERE Id = id_Funcionário) AND  EXISTS (SELECT 1 FROM Donativo WHERE Id = id_Donativo)  AND quantidadeUsada >= 0 THEN

		INSERT INTO mydb.TB_FuncionárioDonativo(D_acesso,Donativo_Id,Funcionário_ID) VALUES(NOW(),id_Donativo,id_Funcionário);
		call consumo_donativo(id_Donativo,quantidadeUsada);
        SELECT 'Sucesso!' AS Resultado;
    ELSE
    ROLLBACK;
    END IF;
    COMMIT;
    SELECT 'Sucesso!' AS Resultado;
END;

