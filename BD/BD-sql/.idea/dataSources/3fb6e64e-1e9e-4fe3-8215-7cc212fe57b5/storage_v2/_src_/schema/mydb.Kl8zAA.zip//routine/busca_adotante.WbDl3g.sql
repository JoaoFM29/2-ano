create
    definer = root@localhost procedure busca_adotante(IN numTel int)
BEGIN
   SELECT Adotante.Nome,Adotante.D_nascimento as "Data de Nascimento",Adotante.N_Porta as "Número da Porta",Adotante.Rua, Adotante.CódigoPostal  FROM Contacto
   INNER JOIN Adotante ON Contacto.Adotante_Id = Adotante.Id
   WHERE Contacto.Número = numTel;
END;

