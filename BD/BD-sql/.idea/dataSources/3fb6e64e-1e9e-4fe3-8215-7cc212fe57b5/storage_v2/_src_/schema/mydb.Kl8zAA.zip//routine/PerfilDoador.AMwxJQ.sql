create
    definer = root@localhost procedure PerfilDoador(IN p_id int, IN p_Email varchar(40), IN p_Nome varchar(40),
                                                    IN p_num int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O Doador existe no sistema' AS Resultado;
    END;

    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM doador WHERE doador.Id = p_id) THEN
        INSERT INTO mydb.doador (Id, Email, Nome, Número) VALUES (p_id, p_Email, p_Nome, p_num);        
        SELECT 'Sucesso: Registro foi realizado!' AS Resultado;
    ELSE
        ROLLBACK;
        SELECT 'Erro: O Doador existe no sistema' AS Resultado;
    END IF;
    
    COMMIT;
END;

