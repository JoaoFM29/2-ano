create
    definer = root@localhost procedure consumo_donativo(IN id_donativo int, IN quant double)
BEGIN 
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O Donativo não existe no sistema' AS Resultado;
    END;

    START TRANSACTION;
    UPDATE donativo 
    SET Quantidade = Quantidade - quant
    WHERE
    id = id_donativo AND D_validade IS NOT NULL;
    Commit;
END;

