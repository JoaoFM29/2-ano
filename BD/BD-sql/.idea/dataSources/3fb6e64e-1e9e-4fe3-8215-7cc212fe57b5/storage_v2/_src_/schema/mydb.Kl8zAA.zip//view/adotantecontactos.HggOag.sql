create definer = root@localhost view adotantecontactos as
select `mydb`.`adotante`.`Id`                                          AS `Id`,
       `mydb`.`adotante`.`Nome`                                        AS `Nome`,
       `mydb`.`adotante`.`D_nascimento`                                AS `D_nascimento`,
       `mydb`.`adotante`.`Sexo`                                        AS `Sexo`,
       `mydb`.`adotante`.`N_Porta`                                     AS `N_Porta`,
       `mydb`.`adotante`.`Rua`                                         AS `Rua`,
       `mydb`.`adotante`.`CódigoPostal`                                AS `CódigoPostal`,
       group_concat(distinct `mydb`.`contacto`.`Número` separator ',') AS `Contactos`
from (`mydb`.`adotante` join `mydb`.`contacto` on ((`mydb`.`adotante`.`Id` = `mydb`.`contacto`.`Adotante_Id`)))
group by `mydb`.`adotante`.`Id`;

