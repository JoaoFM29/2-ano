create definer = root@localhost view doadoremdinheiro as
select `mydb`.`comprovativo`.`IBAN`          AS `IBAN`,
       `mydb`.`comprovativo`.`Operação`      AS `Operação`,
       `mydb`.`comprovativo`.`Montante`      AS `Montante`,
       `mydb`.`comprovativo`.`NomeBanco`     AS `NomeBanco`,
       `mydb`.`comprovativo`.`DataMovimento` AS `DataMovimento`,
       `mydb`.`doador`.`Nome`                AS `Nome`
from ((`mydb`.`comprovativo` join `mydb`.`donativo`
       on ((`mydb`.`comprovativo`.`Donativo_Id` = `mydb`.`donativo`.`Id`))) join `mydb`.`doador`
      on ((`mydb`.`donativo`.`Doador_Id` = `mydb`.`doador`.`Id`)));

