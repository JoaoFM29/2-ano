create definer = root@localhost trigger trigger_update_quantidade
    after insert
    on Comprovativo
    for each row
BEGIN
	UPDATE donativo SET donativo.quantidade = new.montante
		WHERE donativo.Id = new.Donativo_Id;

END;

