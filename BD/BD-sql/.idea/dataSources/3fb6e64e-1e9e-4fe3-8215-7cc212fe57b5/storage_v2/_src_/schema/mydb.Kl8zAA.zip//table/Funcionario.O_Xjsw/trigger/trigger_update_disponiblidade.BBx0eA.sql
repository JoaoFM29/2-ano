create definer = root@localhost trigger trigger_update_disponiblidade
    after insert
    on Funcionário
    for each row
BEGIN
	IF new.Estatuto = 'P' THEN
	INSERT IGNORE INTO mydb.Disponibilidade (Funcionário_Id, DiaDaSemana) VALUES (NEW.Id, 'Segunda-feira');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Terca-feira');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Quarta-feira');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Quinta-feira');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Sexta-feira');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Sabado');
    INSERT IGNORE INTO mydb.Disponibilidade(Funcionário_Id,DiaDaSemana) VALUES (new.Id,'Domingo');
    END IF;

END;

