create
    definer = root@localhost procedure listar_donativos(IN date1 date, IN date2 date)
BEGIN
    SELECT * FROM Donativo
    WHERE Donativo.D_validade BETWEEN date1 AND date2 or Donativo.D_validade AND Donativo.D_validade IS NOT NULL
	ORDER BY Donativo.D_validade ASC;
END;

