create
    definer = root@localhost procedure adicionar_contacto(IN id_Adotante int, IN num int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: Algum Id está incorreto' AS Resultado;
    END;
    START TRANSACTION;
    
    IF EXISTS (SELECT 1 FROM adotante WHERE adotante.Id = id_Adotante) AND NOT EXISTS (SELECT 1 FROM contacto WHERE contacto.Número = num) THEN
        INSERT INTO mydb.contacto (Número, Adotante_Id) VALUES (num, id_Adotante);
        SELECT 'Sucesso: Operação foi realizada!' AS Resultado;
    ELSE
        ROLLBACK;
        SELECT 'Erro: Algum Id está incorreto ou Número já existente' AS Resultado;
    END IF;
    
    COMMIT;
END;

