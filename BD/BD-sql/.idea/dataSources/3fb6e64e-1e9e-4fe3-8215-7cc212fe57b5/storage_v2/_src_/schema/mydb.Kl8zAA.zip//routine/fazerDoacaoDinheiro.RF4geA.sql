create
    definer = root@localhost procedure fazerDoaçãoDinheiro(IN p_id int, IN d_id int, IN c_IBAN varchar(45),
                                                           IN c_Operação varchar(45), IN c_Montante double,
                                                           IN c_NomeBanco varchar(60), IN c_DataMovimento datetime)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O Doador não existe no sistema ou o donativo não é válido' AS Resultado;
    END;

    START TRANSACTION;
    
    IF EXISTS (SELECT 1 FROM doador WHERE doador.Id = p_id) THEN
        INSERT INTO mydb.donativo (Id,Categoria,D_validade, Quantidade,Doador_Id) VALUES (d_id,"Dinheiro", null, null,p_id);
        INSERT INTO mydb.comprovativo (IBAN,Operação,Montante, NomeBanco,Donativo_Id,DataMovimento) VALUES (c_IBAN,c_Operação,c_Montante, c_NomeBanco,d_id,c_DataMovimento);   
        
        SELECT 'Sucesso: Doação foi realizada!' AS Resultado;
    ELSE
        ROLLBACK;
         SELECT 'Sucesso: Doação não foi realizada!' AS Resultado;
    END IF;
    
    COMMIT;
END;

