create
    definer = root@localhost procedure MaisQueUmaAdoção(IN p_id int, IN animal_adotado_id int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O adotante não existe no sistema ou o ID do animal está incorreto' AS Resultado;
    END;

    START TRANSACTION;
    
    IF EXISTS (SELECT 1 FROM Adotante WHERE Id = p_id) AND EXISTS (SELECT 1 FROM Animal WHERE id = animal_adotado_id AND D_adoção is NULL) THEN
        
        UPDATE Animal SET Animal.Adotante_Id = p_id, Animal.D_adoção = NOW() WHERE Animal.id = animal_adotado_id;
        
        SELECT 'Sucesso!' AS Resultado;
    ELSE
       
        ROLLBACK;
    END IF;
    
    COMMIT;
    SELECT 'Sucesso: Adoção foi realizada!' AS Resultado;
END;

