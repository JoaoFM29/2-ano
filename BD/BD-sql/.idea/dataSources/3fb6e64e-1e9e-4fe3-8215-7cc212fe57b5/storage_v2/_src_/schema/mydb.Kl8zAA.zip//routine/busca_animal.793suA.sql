create
    definer = root@localhost procedure busca_animal(IN id_animal int)
BEGIN 
    SELECT * FROM animal 
    WHERE id = id_animal; -- id varia em função do animal
END;

