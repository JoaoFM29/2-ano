create
    definer = root@localhost procedure chegadaAnimal(IN a_id int, IN a_Nome varchar(40), IN a_Idade int,
                                                     IN a_Perfil varchar(45), IN a_D_nascimento date,
                                                     IN a_Registo_clinico text, IN a_Categoria varchar(20),
                                                     IN a_Cor varchar(20), IN a_Sexo char, IN a_Raca varchar(20),
                                                     IN a_Peso int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O Animal existe no sistema' AS Resultado;
    END;

    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM animal WHERE Id = a_id) THEN
        INSERT INTO mydb.animal(id,Nome,Idade,Perfil,D_nascimento,Registo_Clinico,Categoria,Cor,D_adoção,D_saida,D_chegada,Sexo,`Raça e espécie`,Peso,Adotante_Id)
                 VALUES (a_id,a_nome,a_Idade,a_Perfil,a_D_nascimento ,a_Registo_clinico,a_Categoria,a_Cor,NULL,NULL,NOW(),a_Sexo,a_Raca,a_Peso ,NULL);
        SELECT 'Sucesso!' AS Resultado;
    ELSE
        ROLLBACK;
        SELECT 'Erro!' AS Resultado;
    END IF;
    
    COMMIT;
END;

