create definer = root@localhost view funcionariocompetenciasdisponiblidade as
select `mydb`.`funcionário`.`Nome`                                                 AS `Nome`,
       group_concat(distinct `mydb`.`competência`.`Aptidão` separator ',')         AS `comp_combinadas`,
       group_concat(distinct `mydb`.`disponibilidade`.`DiaDaSemana` separator ',') AS `Disp_combinadas`
from ((`mydb`.`funcionário` join `mydb`.`competência`
       on ((`mydb`.`funcionário`.`Id` = `mydb`.`competência`.`Funcionário_Id`))) join `mydb`.`disponibilidade`
      on ((`mydb`.`funcionário`.`Id` = `mydb`.`disponibilidade`.`Funcionário_Id`)))
group by `mydb`.`funcionário`.`Nome`;

