create
    definer = root@localhost procedure PerfilFuncionário(IN f_id int, IN f_Nome varchar(45), IN f_Email varchar(40),
                                                         IN f_Estatuto varchar(1), IN f_rua varchar(45),
                                                         IN f_N_Porta int, IN f_CódigoPostal int, IN f_Número int,
                                                         IN DispString varchar(255), IN AptString varchar(255))
BEGIN
    DECLARE weekdayValue VARCHAR(20);
    DECLARE AptValue VARCHAR(40);
    DECLARE startIndex INT;
    DECLARE endIndex INT;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O Funcionário existe no sistema' AS Resultado;
    END;

    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM funcionário WHERE funcionário.Id = f_id) THEN
    
        INSERT INTO funcionário (Id, Nome, Email, Estatuto, Rua, N_Porta, CódigoPostal, Número) 
        VALUES (f_id, f_Nome, f_Email, f_Estatuto, f_rua, f_N_Porta, f_CódigoPostal, f_Número);
        
		-- Insert competências
        SET startIndex = 1;
        SET endIndex = LOCATE(',', AptString);
		
        WHILE endIndex > 0 DO
            SET AptValue = SUBSTRING(AptString, startIndex, endIndex - startIndex);
				
            -- Perform the insert operation for each aptidão
            INSERT INTO competência (aptidão,Funcionário_Id)
            VALUES (AptValue, f_id);

            -- Update the loop variables
            SET startIndex = endIndex + 1;
            SET endIndex = LOCATE(',', AptString, startIndex);
        END WHILE;

        -- Insert the last aptidão value
        SET AptValue = SUBSTRING(AptString, startIndex);
        INSERT INTO competência (aptidão,Funcionário_Id)
        VALUES (AptValue, f_id);

        -- Insert funcionário
        
        IF f_Estatuto = 'V' THEN
            -- Initialize the loop
            SET startIndex = 1;
            SET endIndex = LOCATE(',', DispString);
			SELECT startIndex, endIndex, AptValue;
            -- Loop through the weekday values
            WHILE endIndex > 0 DO
                SET weekdayValue = SUBSTRING(DispString, startIndex, endIndex - startIndex);

                -- Perform the insert operation for each weekday
                INSERT INTO disponibilidade (Funcionário_Id, DiaDaSemana) 
                VALUES (f_id, weekdayValue);

                -- Update the loop variables
                SET startIndex = endIndex + 1;
                SET endIndex = LOCATE(',', DispString, startIndex);
            END WHILE;

            -- Insert the last weekday value
            SET weekdayValue = SUBSTRING(DispString, startIndex);
            INSERT INTO disponibilidade (Funcionário_Id, DiaDaSemana) 
            VALUES (f_id, weekdayValue);
        END IF;

        SELECT 'Sucesso: Registro foi realizado!' AS Resultado;
    ELSE
        ROLLBACK;
        SELECT 'Erro: O Funcionário existe no sistema' AS Resultado;
    END IF;
    
    COMMIT;
END;

