create
    definer = root@localhost procedure PrimeiraAdoção(IN p_id int, IN p_Nome varchar(40), IN p_D_nascimento date,
                                                      IN p_Sexo char, IN p_N_Porta int, IN p_Rua varchar(40),
                                                      IN p_CódigoPostal int, IN p_Contacto int,
                                                      IN animal_adotado_id int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: O adotante existe no sistema ou o ID do animal está incorreto' AS Resultado;
    END;

    START TRANSACTION;
    
    IF NOT EXISTS (SELECT 1 FROM Adotante WHERE Id = p_id) AND EXISTS (SELECT 1 FROM Animal WHERE id = animal_adotado_id AND D_adoção is NULL) THEN
    
        INSERT INTO mydb.adotante (Id, Nome, D_nascimento, Sexo, N_Porta, Rua, CódigoPostal)  VALUES (p_id, p_Nome, p_D_nascimento, p_Sexo, p_N_Porta, p_Rua, p_CódigoPostal);
        
        INSERT INTO mydb.Contacto (Adotante_id, Número) VALUES (p_id, p_Contacto);
        
        UPDATE Animal SET Animal.Adotante_Id = p_id, Animal.D_adoção = NOW() WHERE Animal.id = animal_adotado_id;
        
        SELECT 'Sucesso!' AS Resultado;
    ELSE

        ROLLBACK;
    END IF;
    
    COMMIT;
    SELECT 'Sucesso: Adoção foi realizada!' AS Resultado;
END;

