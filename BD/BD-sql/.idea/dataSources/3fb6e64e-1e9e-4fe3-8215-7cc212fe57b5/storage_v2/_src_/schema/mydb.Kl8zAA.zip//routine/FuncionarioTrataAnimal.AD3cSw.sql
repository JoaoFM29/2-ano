create
    definer = root@localhost procedure FuncionárioTrataAnimal(IN id_Funcionário int, IN id_Animal int)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Erro: Algum Id está incorreto' AS Resultado;
    END;
    START TRANSACTION;
    IF EXISTS (SELECT 1 FROM Funcionário WHERE Id = id_Funcionário) AND  EXISTS (SELECT 1 FROM Animal WHERE Id = id_Animal) THEN

		INSERT INTO mydb.tb_animalfuncionário(D_tratamento,Animal_Id,Funcionário_ID) VALUES(NOW(),id_Animal,id_Funcionário);
        SELECT 'Sucesso!' AS Resultado;
    ELSE
    ROLLBACK;
    END IF;
    COMMIT;
    SELECT 'Sucesso!' AS Resultado;
END;

