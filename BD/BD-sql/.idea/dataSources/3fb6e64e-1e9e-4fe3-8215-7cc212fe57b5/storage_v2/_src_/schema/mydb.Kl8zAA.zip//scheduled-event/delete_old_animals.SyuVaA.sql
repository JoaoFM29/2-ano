create definer = root@localhost event delete_old_animals on schedule
    every '1' DAY
        starts '2023-06-06 10:43:46'
    enable
    do
    BEGIN
    DELETE FROM Animal WHERE DATE_ADD(D_saida, INTERVAL 60 DAY) < CURDATE();
END;

